#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

// [[Rcpp::depends(RcppArmadillo)]]

// Nadaraya-Watson kernel regression estimator
// [[Rcpp::export]]
arma::vec NW_c(const arma::vec& x, const arma::vec& X, const arma::vec& Y, double h, Function K) {
  int G = x.n_elem;
  arma::vec results(G);  // Vector to store the results for each x
  
  for (int i = 0; i < G; ++i) {
    // Compute the scaled difference for the current x[i]
    arma::vec scaled_diff = (x[i] - X) / h;
    arma::vec K_vals = as<arma::vec>(K(scaled_diff));
    
    // Calculate the denominator and numerator
    double denom = sum(K_vals);
    double num = sum(K_vals % Y);  // Element-wise multiplication with Y
    
    // Store the result for x[i]
    results[i] = num / denom;
  }
  
  return results;
}

// Generalized Nearest Neighbor Regression
// [[Rcpp::export]]
arma::vec GNN_c(const arma::vec& x, const arma::vec& X, const arma::vec& Y, int h, Function K) {
  int n = x.n_elem;
  arma::vec g_NN(n);  // Output vector
  
  for (int i = 0; i < n; ++i) {
    // Find the distance of the k-th nearest neighbor
    arma::vec distances = abs(X - x[i]);
    arma::uvec sorted_indices = sort_index(distances);
    double h_dist = distances(sorted_indices[h - 1]);  // Nearest neighbor distance
    
    // Calculate kernel weights and normalize
    arma::vec scaled_diff = (X - x[i]) / h_dist;
    arma::vec K_vals = as<arma::vec>(K(scaled_diff));
    double dm = sum(K_vals);
    
    // Weighted sum of Y values
    g_NN[i] = sum(Y % K_vals) / dm;  // Element-wise multiplication and normalization
  }
  
  return g_NN;
}

