#' Backfitting algorithm with two covariates
#'
#' Estimate a function evaluted at design points, using backfitting.
#'
#' @param x the matrix of design points.
#' @param X the matrix of two covariates.
#' @param Y the vector of response.
#' @param h a positive scalar value, the bandwidth.
#' @param K a kernel function.
#' @param smoother a string containing the chosen univariate smoother. Currently only "NW" is supported.
#'
#' @return
#' a `list` containing the design points `x` and estimated values `y` of the
#' function evaluated at the design points.
#'
#' @examples
#' # dumb example
#' n = 100
#' x = matrix(c(0,0), nrow=1, ncol=2)
#' X = cbind(runif(n,0,1), runif(n,0,1))
#' m = function(x) 0.7*exp(-3*(x[1]-0.8)^2)+exp(-24*(x[2]-0.5)^2)
#' Y = sapply(X, function(u) m(u))
#'
#' Kepan <- function(u){0.75 * (1 - u^2) * (abs(u) <= 1)}
#'
#' backfitting(x,X,Y,h=0.01,Kepan,smoother="NW")
#'
#' @export
#'
backfitting<-function(x,X,Y,h,K,smoother="NW"){

  if (smoother == "NW"){
    smthr = NW_c
  } else if (smoother == "GNN"){
    if (h != floor(h)){ stop("If smoother = 'GNN', please use integer-valued h.") }
    smthr = GNN_c
  } else if (smoother == "spline"){
    stop("Please use the gam() function from library 'gam'.")
  } else {
    stop("Supported smoothers are 'NW' and 'GNN'.")
  }

  # initialization
  maxIter=100
  alpha<-mean(Y)
  n<-length(Y)
  d=ncol(X)
  G=nrow(x)
  x=rbind(x,X)

  m0<-lm((Y-alpha)~X-1) # initialization with a linear model
  S_curr<-matrix(0, G + n, d)
  for (j in 1:d){
    S_curr[,j] = coef(m0)[j]*x[,j]
    S_curr[,j] = S_curr[,j]-mean(S_curr[,j])
  }

  l=0
  while(l< maxIter){
    l=l+1
    S_next = matrix(0, G + n, d)

    for(j in 1:d){
      Yt_j <- Y - alpha - S_curr[G+(1:n),-j]
      S_next[,j]<-sapply(x[,j],function(u) smthr(u,X[,j],Yt_j,h,K))
      S_next[,j]<-S_next[,j]-mean(S_next[,j])
    }

    if(all(abs(S_curr-S_next)<1e-3)){break}
    S_curr<-S_next
  }


  if(l>maxIter){
    print("The algorithm did not converge")
  }

  Yhat = alpha+rowSums(S_next)

  return(list(x=x[1:G,], y = Yhat[1:G]))
}
